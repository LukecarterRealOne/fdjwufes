# VLine Practice Tools (Fabric, Minecraft 26.1.2)

A visible practice helper intended for **offline single-player worlds only**. It does not include anti-cheat bypass or stealth behavior.

## Features

- **F6 — Hitbox help:** shows the built-in Minecraft hitbox shortcut (default F3+B).
- **F7 — Proximity alerts:** shows a notice when your aim ray is near a mob's slightly expanded bounding box.
- **F8 — Training auto-hit:** attacks only mobs in offline single-player when Minecraft's normal crosshair already targets that same mob and the normal attack cooldown is ready. It does not add reach and never targets players.

## Build through GitHub Actions

You can either upload the extracted project files to your repository root, or upload this complete ZIP as `vline-practice-tools-current-source.zip` to the repository root. The workflow scans ZIP files and chooses a complete project whose Java source no longer calls the removed `EntityRenderDispatcher.shouldRenderHitboxes()` method.

1. Download `vline-practice-tools-current-source.zip`.
2. In your GitHub repository, delete the old `vline-practice-tools-source-fixed.zip` and upload this new ZIP at the repository root. Keep `.github/workflows/build.yml` updated with the workflow included in this bundle (or replace it with the standalone workflow supplied separately).
3. Commit the changes and open **Actions → Build VLine Practice Tools**.
4. When the run succeeds, download the `vline-practice-tools-minecraft-26.1.2` artifact and place the main mod JAR (not a `-sources.jar`) in your `mods` folder.

## Requirements

- Minecraft Java Edition 26.1.2
- Fabric Loader 0.19.5 or newer
- Fabric API 0.155.3+26.1.2
- Java 25

This is a source project, not a precompiled mod JAR. The complete Gradle build and in-game behavior must still be verified by running GitHub Actions and testing in Minecraft.
